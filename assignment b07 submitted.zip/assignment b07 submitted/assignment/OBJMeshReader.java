package assignment;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
public class OBJMeshReader implements MeshReader {
	@Override
	public HashSet<Polygon> read(String fileName)throws FileNotFoundException, WrongFileFormatException {
		Scanner sca= new Scanner(new FileReader(fileName));
		ArrayList<String> str=new ArrayList<String>();
		HashSet<Polygon> result = new HashSet<Polygon>();
		String pattern = "v(\\s*-?\\d+\\.?\\d*\\s*){3}.*";
		//String pattern="v\\s+\\-?\\d+\\.*\\d*\\s+\\-?\\d+\\.*\\d*.*";
		//String pattern="v\\s+\\-?\\d+\\.*\\d*\\s+\\-?\\d+\\.*\\d*\\s+\\-?\\d+\\.*\\d*.*";
		Pattern pa = Pattern.compile(pattern);
		boolean matches = true;
		String pattern2="f(\\s*\\d+\\s*)+";
		Pattern pa2 = Pattern.compile(pattern2);
		boolean matches2 = true;
		while(sca.hasNextLine()){
			String line = sca.nextLine();
			Matcher m = pa.matcher(line);
			matches = m.matches();
			Matcher m2 = pa2.matcher(line);
			matches2 = m2.matches();
			if(matches ==false&&matches2==false) {
				throw new WrongFileFormatException("this is not an obj file");
			}
			str.add(line);
		}
		int i = 0;
		for(String s: str) {
			if (s.charAt(0)!='f') {
				i++;
			}
		}
		for(int z=i;z<str.size();z++) {
			String sp = str.get(z);
			String[] strlist=sp.split("\\s+");
			LinkedHashSet<Vertex> v = new LinkedHashSet<Vertex>();
			for(int y=1;y<strlist.length;y++) {
				String need = str.get(Integer.valueOf(strlist[y])-1);
				String[] divid = need.split("\\s+");
				Vertex addvertex = new Vertex(Double.parseDouble(divid[1]),Double.parseDouble(divid[2]),Double.parseDouble(divid[3]));
	            v.add(addvertex);
			}
			Polygon p = new Polygon(v);
			result.add(p);
		}
		sca.close();
		return result;
	}
}
