package assignment;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedHashSet;

import org.junit.jupiter.api.Test;

class Assignment_test {
	
	String PATH = "C:\\Users\\15810\\eclipse-workspace\\assignment 1 cscb07";
			
	//mesh.read(PATH + "\\src\\mytest\\empty.txt")
	@Test
	void testequalsvertex1() {
		Vertex v = new Vertex(1.3,1.4,1.6);
		Vertex b = null;
		assertFalse(v.equals(b));
	}
	@Test
	void testequalsvertex2() {
		Vertex v = new Vertex(1,1,1);
		Polygon b = new Polygon(null);
		assertFalse(v.equals(b));
	}
	@Test
	void testequalsvertex3() {
		Vertex v = new Vertex(1,1,1);
		Vertex b = new Vertex(1,1.2,1);
		assertFalse(v.equals(b));
	}
	@Test
	void testequalsvertex5() {
		Vertex v = new Vertex(1,1,1);
		Vertex b = new Vertex(1.2,1,1);
		assertFalse(v.equals(b));
	}
	@Test
	void testequalsvertex6() {
		Vertex v = new Vertex(1,1,1);
		Vertex b = new Vertex(1,1,1.2);
		assertFalse(v.equals(b));
	}
	@Test
	void testequalsvertex4() {
		Vertex v = new Vertex(1,1,1);
		Vertex b = new Vertex(1,1,1);
		assertTrue(v.equals(b));
	}
	@Test
	void testtostringvertex() {
		Vertex v = new Vertex(1,5,1);
		assertEquals(v.toString(),"1.0 5.0 1.0");
	}
	@Test
	void testhashcodevertex() {
		Vertex v = new Vertex(1,5,1);
		assertEquals(v.hashCode(),1510);
	}
	@Test
	void testtransformv() {
		Vertex v = new Vertex(1,5,1);
		double[][] rotate={{0,1,0},{1,1,1},{2,0,1}};
		v.transform(rotate);
		Vertex y = new Vertex(5,7,3);
		assertEquals(v,y);
	}
	@Test
	void testrotatex() {
		Vertex v = new Vertex(2,3,1);
		v.rotateXAxis(3.141592653589793);
		v.x=Math.round(v.x);
		v.y=Math.round(v.y);
		v.z=Math.round(v.z);
		Vertex a = new Vertex(2,-3,-1);
		assertEquals(v,a);
	}
	@Test
	void testrotatey() {
		Vertex v = new Vertex(2,3,1);
		v.rotateYAxis(3.141592653589793/2.0);
		v.x=Math.round(v.x);
		v.y=Math.round(v.y);
		v.z=Math.round(v.z);
		Vertex a = new Vertex(1,3,-2);
		assertEquals(v,a);
	}
	@Test
	void testrotatez() {
		Vertex v = new Vertex(2,3,1);
		v.rotateZAxis(3.141592653589793);
		v.x=Math.round(v.x);
		v.y=Math.round(v.y);
		v.z=Math.round(v.z);
		Vertex a = new Vertex(-2,-3,1);
		assertEquals(v,a);
	}
	@Test
	void testtransformpolygon() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b= new Polygon(a);
		double[][] rotate = {{0,1,0},{1,1,1},{1,0,1}};
		b.transform(rotate);
		Vertex f = new Vertex(3,2,-1);
		Vertex g = new Vertex(2,6,4);
		LinkedHashSet<Vertex> c = new LinkedHashSet<Vertex>();
		c.add(f);
		c.add(g);
		assertEquals(c,b.vertices);
	}
	@Test
	void testhashcodepolygon() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b = new Polygon(a);
		assertEquals(b.hashCode(),2510);
	}
	@Test
	void testequalspolygon1() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b = new Polygon(a);
		Polygon c = null;
		assertFalse(b.equals(c));
	}
	@Test
	void testequalspolygon2() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b = new Polygon(a);
		Vertex c = new Vertex(1,1,1);
		assertFalse(b.equals(c));
	}
	@Test
	void testequalspolygon3() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b = new Polygon(a);
		LinkedHashSet<Vertex> f = new LinkedHashSet<Vertex>();
		f.add(e);
		Polygon c = new Polygon(f);
		assertFalse(b.equals(c));
	}
	@Test
	void testequalspolygon4() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b = new Polygon(a);
		LinkedHashSet<Vertex> f = new LinkedHashSet<Vertex>();
		f.add(e);
		Vertex z = new Vertex(2,2,2);
		f.add(z);
		Polygon c = new Polygon(f);
		assertFalse(b.equals(c));
	}
	@Test
	void testequalspolygon5() {
		LinkedHashSet<Vertex> a = new LinkedHashSet<Vertex>();
		Vertex d = new Vertex(1,3,-2);
		Vertex e = new Vertex(1,2,3);
		a.add(e);
		a.add(d);
		Polygon b = new Polygon(a);
		LinkedHashSet<Vertex> f = new LinkedHashSet<Vertex>();
		Vertex g = new Vertex(1,2,3);
		Vertex h = new Vertex(1,3,-2);
		f.add(h);
		f.add(g);
		Polygon c = new Polygon(f);
		assertTrue(b.equals(c));
	}
	@Test
	void test1forobjread() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\empty.txt";
		//String s = "..\\src\\empty.txt";
		String s = PATH + "\\src\\mytest\\empty.txt";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		HashSet<Polygon> p = new HashSet<Polygon>();
		assertEquals(p,g.polygons);
	}
	@Test
	void test2forobjread() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\testsampleobj.txt";
		String s = PATH + "\\src\\mytest\\testsampleobj.txt";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		HashSet<Polygon> p = new HashSet<Polygon>();
		Vertex a = new Vertex(5.1,1.2,0.3);
		Vertex b = new Vertex(4.9,1.5,0.3);
		Vertex c = new Vertex(3.8,1.4,0.5);
		Vertex d = new Vertex(4.1,1.6,0.6);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		w.add(b);
		w.add(c);
		w.add(d);
		Polygon f = new Polygon(w);
		p.add(f);
		p.add(e);
		assertEquals(p,g.polygons);
	}
	@Test
	void testMeshtransform() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\testtransform.txt";
		String s = PATH + "\\src\\mytest\\testtransform.txt";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		Vertex a = new Vertex(5,1,3);
		Vertex b = new Vertex(4,1,3);
		Vertex c = new Vertex(3,1,5);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		Vertex i = new Vertex(4,1,3);
		Vertex j = new Vertex(3,1,5);
		Vertex k = new Vertex(4,6,6);
		w.add(i);
		w.add(j);
		w.add(k);
		Polygon f = new Polygon(w);
		HashSet<Polygon> p = new HashSet<Polygon>();
		double[][] rotate={{1,0,0},{0,0,0},{0,0,1}};
		p.add(e);
		p.add(f);
		for(Polygon h:p) {
			h.transform(rotate);
		}
		g.transform(rotate);
		assertTrue(g.polygons.equals(p));
	}
	@Test
	void testhashcodemesh() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\test1.obj";
		String s = PATH + "\\src\\mytest\\test1.obj";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		assertEquals(5790,g.hashCode());
		
	}
	@Test
	void testmeshequal1() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\testsampleobj.txt";
		String s = PATH + "\\src\\mytest\\testsampleobj.txt";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		Mesh h = new Mesh();
		h=null;
		assertFalse(g.equals(h));
	}
	@Test
	void testmeshequa2() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\testsampleobj.txt";
		String s = PATH + "\\src\\mytest\\testsampleobj.txt";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		Vertex h = new Vertex(1,1,1);
		assertFalse(g.equals(h));
	}
	@Test
	void testmeshequa3() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\test3.obj";
		String s = PATH + "\\src\\mytest\\test3.obj";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		Mesh h = new Mesh();
		h.setReader(new OBJMeshReader());
		h.readFromFile(s);
		assertTrue(g.equals(h));
	}
	@Test
	void testmeshequa4() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\test3.obj";
		String s = PATH + "\\src\\mytest\\test3.obj";
		g.setReader(new OBJMeshReader());
		g.readFromFile(s);
		Mesh h = new Mesh();
		Vertex v1 = new Vertex(1,2,3);
		Vertex v2 = new Vertex(3,4,5);
		Vertex v3 = new Vertex(6,7,8);
		Vertex v4 = new Vertex(9,10,11);
		LinkedHashSet<Vertex> ff1 = new LinkedHashSet<Vertex>();
		LinkedHashSet<Vertex> ff2 = new LinkedHashSet<Vertex>();
		LinkedHashSet<Vertex> ff3 = new LinkedHashSet<Vertex>();
		ff1.add(v1);
		ff1.add(v2);
		ff2.add(v4);
		ff2.add(v3);
		ff3.add(v3);
		ff3.add(v1);
		Polygon f1 = new Polygon(ff1);
		Polygon f2 = new Polygon(ff2);
		Polygon f3 = new Polygon(ff3);
		HashSet<Polygon> z = new HashSet<Polygon>();
		z.add(f3);
		z.add(f2);
		z.add(f1);
		h.polygons=z;
		assertFalse(g.equals(h));
	}	
	@Test
	void testplymeshreader() throws IOException, WrongFileFormatException {
		Mesh g = new Mesh();
		//String s = "C:\\Users\\15810\\testcase\\mytest\\testsampleply.txt";
		String s = PATH + "\\src\\mytest\\testsampleply.txt";
		g.setReader(new PLYMeshReader());
		g.readFromFile(s);
		HashSet<Polygon> p = new HashSet<Polygon>();
		Vertex a = new Vertex(5.1,1.2,0.3);
		Vertex b = new Vertex(4.9,1.5,0.3);
		Vertex c = new Vertex(3.8,1.4,0.5);
		Vertex d = new Vertex(4.1,1.6,0.6);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		w.add(b);
		w.add(c);
		w.add(d);
		Polygon f = new Polygon(w);
		p.add(f);
		p.add(e);
		assertEquals(p,g.polygons);
	}	
	@Test
	void testOBJMeshWriter() throws IOException, WrongFileFormatException {
		Mesh h = new Mesh();
		HashSet<Polygon> p = new HashSet<Polygon>();
		Vertex a = new Vertex(5.1,1.2,0.3);
		Vertex b = new Vertex(4.9,1.5,0.3);
		Vertex c = new Vertex(3.8,1.4,0.5);
		Vertex d = new Vertex(4.1,1.6,0.6);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		w.add(b);
		w.add(c);
		w.add(d);
		Polygon f = new Polygon(w);
		p.add(f);
		p.add(e);
		h.polygons=p;
		h.setWriter(new OBJMeshWriter());
		//h.writeToFile("C:\\Users\\15810\\testcase\\mytest\\createobj.txt");
		h.writeToFile(PATH+"\\src\\mytest\\createobj.txt");
		Mesh g = new Mesh();
		g.setReader(new OBJMeshReader());
		//g.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleobj.txt");
		g.readFromFile(PATH+"\\src\\mytest\\createobj.txt");
		assertTrue(g.equals(h));
	}
	@Test
	void testPLYMeshWriter() throws IOException, WrongFileFormatException {
		Mesh h = new Mesh();
		HashSet<Polygon> p = new HashSet<Polygon>();
		Vertex a = new Vertex(5.1,1.2,0.3);
		Vertex b = new Vertex(4.9,1.5,0.3);
		Vertex c = new Vertex(3.8,1.4,0.5);
		Vertex d = new Vertex(4.1,1.6,0.6);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		w.add(b);
		w.add(c);
		w.add(d);
		Polygon f = new Polygon(w);
		p.add(f);
		p.add(e);
		h.polygons=p;
		h.setWriter(new PLYMeshWriter());
		//h.writeToFile("C:\\Users\\15810\\testcase\\mytest\\createply.txt");
		h.writeToFile(PATH+"\\src\\mytest\\createply.txt");
		Mesh g = new Mesh();
		g.setReader(new PLYMeshReader());
		//g.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleply.txt");
		g.readFromFile(PATH+"\\src\\mytest\\createply.txt");
		assertTrue(g.equals(h));
	}
	@Test
	void testOFFMeshReader() throws IOException, WrongFileFormatException {
		Mesh h = new Mesh();
		HashSet<Polygon> p = new HashSet<Polygon>();
		Vertex a = new Vertex(5.1,1.2,0.3);
		Vertex b = new Vertex(4.9,1.5,0.3);
		Vertex c = new Vertex(3.8,1.4,0.5);
		Vertex d = new Vertex(4.1,1.6,0.6);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		w.add(b);
		w.add(c);
		w.add(d);
		Polygon f = new Polygon(w);
		p.add(f);
		p.add(e);
		h.polygons=p;
		Mesh g = new Mesh();
		g.setReader(new OFFMeshReader());
		//g.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleoff.txt");
		g.readFromFile(PATH+"\\src\\mytest\\testsampleoff.txt");
		assertTrue(g.equals(h));
	}
	@Test
	void testOFFMeshWriterReader() throws IOException, WrongFileFormatException {
		Mesh h = new Mesh();
		HashSet<Polygon> p = new HashSet<Polygon>();
		Vertex a = new Vertex(5.1,1.2,0.3);
		Vertex b = new Vertex(4.9,1.5,0.3);
		Vertex c = new Vertex(3.8,1.4,0.5);
		Vertex d = new Vertex(4.1,1.6,0.6);
		LinkedHashSet<Vertex> v= new LinkedHashSet<Vertex>();
		v.add(a);
		v.add(b);
		v.add(c);
		Polygon e = new Polygon(v);
		LinkedHashSet<Vertex> w= new LinkedHashSet<Vertex>();
		w.add(b);
		w.add(c);
		w.add(d);
		Polygon f = new Polygon(w);
		p.add(f);
		p.add(e);
		h.polygons=p;
		h.setWriter(new OFFMeshWriter());
		//h.writeToFile("C:\\Users\\15810\\testcase\\mytest\\createoff.txt");
		h.writeToFile(PATH+"\\src\\mytest\\createoff.txt");
		Mesh g = new Mesh();
		g.setReader(new OFFMeshReader());
		//g.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleoff.txt");
		g.readFromFile(PATH+"\\src\\mytest\\createoff.txt");
		assertTrue(g.equals(h));
	}
	
	@Test
	void testplyexception() throws FileNotFoundException {
		Mesh mesh=new Mesh();
		mesh.setReader(new PLYMeshReader());
		try {
			//mesh.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleobj.txt");
			mesh.readFromFile(PATH+"\\src\\mytest\\testsampleobj.txt");
		} catch (WrongFileFormatException e) {
			assertEquals(e.message,"this is not a ply file");
		}
		
	}
	@Test
	void testplyexception2() throws FileNotFoundException {
		Mesh mesh=new Mesh();
		mesh.setReader(new PLYMeshReader());
		try {
			//mesh.readFromFile("C:\\Users\\15810\\testcase\\mytest\\empty.txt");
			mesh.readFromFile(PATH+"\\src\\mytest\\empty.txt");
		} catch (WrongFileFormatException e) {
			assertEquals(e.message,"this is not a ply file");
		}
		
	}
	@Test
	void testplywrongfile() throws FileNotFoundException, WrongFileFormatException {
		Mesh mesh=new Mesh();
		mesh.setReader(new PLYMeshReader());
		//mesh.readFromFile("C:\\Users\\15810\\testcase\\mytest\\wrongply.txt");
		mesh.readFromFile(PATH+"\\src\\mytest\\wrongply.txt");
		assertTrue(mesh.polygons==null);
		
	}
	
	@Test
	void testplywrongfile2() throws FileNotFoundException {
		Mesh mesh=new Mesh();
		mesh.setReader(new PLYMeshReader());
		try {
			//mesh.readFromFile("C:\\Users\\15810\\testcase\\mytest\\wrongply2.txt");
			mesh.readFromFile(PATH+"\\src\\mytest\\wrongply2.txt");
		} catch (WrongFileFormatException e) {
			assertEquals(e.message,"this is not a ply file");
		}
		
	}
	@Test
	void testobjexception() throws FileNotFoundException {
		Mesh mesh=new Mesh();
		mesh.setReader(new OBJMeshReader());
		try {
			//mesh.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleply.txt");
			mesh.readFromFile(PATH+"\\src\\mytest\\testsampleply.txt");
		} catch (WrongFileFormatException e) {
			assertEquals(e.message,"this is not an obj file");
		}
		
	}
	@Test
	void testoffexception() throws FileNotFoundException {
		Mesh mesh=new Mesh();
		mesh.setReader(new OFFMeshReader());
		try {
			//mesh.readFromFile("C:\\Users\\15810\\testcase\\mytest\\testsampleobj.txt");
			mesh.readFromFile(PATH+"\\src\\mytest\\testsampleply.txt");
		} catch (WrongFileFormatException e) {
			assertEquals(e.message,"this is not an off file");
		}
		
	}
	
	


}
