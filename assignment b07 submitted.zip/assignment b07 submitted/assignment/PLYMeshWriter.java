package assignment;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

public class PLYMeshWriter implements MeshWriter{
	public void write(String fileName, HashSet<Polygon> polygons) throws IOException{
		FileWriter f = new FileWriter(fileName,false);
		ArrayList<Vertex> ver= new ArrayList<Vertex>();
		for(Polygon p: polygons) {
			for(Vertex v:p.vertices) {
				if (ver.contains(v)==false) {
					ver.add(v);
				}
			}
		}
		f.write("ply"+"\n");
		f.write("format ascii 1.0"+"\n");
		f.write("element vertex "+Integer.toString(ver.size())+"\n");
		f.write("property float32 x\n");
		f.write("property float32 y\n");
		f.write("property float32 z\n");
		f.write("element face "+Integer.toString(polygons.size())+"\n");
		f.write("property list uint8 int32 vertex_indices\n");
		f.write("end_header\n");
		for(Vertex v:ver) {
			String a = String.valueOf(v.x)+" "+String.valueOf(v.y)+" "+String.valueOf(v.z);
			f.write(a+"\n");
		}
		for(Polygon p:polygons) {
			f.write(String.valueOf(p.vertices.size()));
			for(Vertex x:p.vertices) {
				for(int i=0;i<ver.size();i++) {
					if(x.equals(ver.get(i))){
						f.write(" ");
						f.write(String.valueOf(i));
						break;
					}
				}
			}
			f.write("\n");
		}
		f.close();
	}
}
