package assignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PLYMeshReader implements MeshReader {
	public HashSet<Polygon> read(String fileName) throws FileNotFoundException, WrongFileFormatException{
		Scanner sca= new Scanner(new File(fileName));
		ArrayList<String> str=new ArrayList<String>();
		HashSet<Polygon> result = new HashSet<Polygon>();
		String pattern="(\\s*\\-?\\d+\\.*\\d*\\s*){3}\\s*";
		Pattern pa = Pattern.compile(pattern);
		boolean matches = true;
		String pattern2="(\\s*\\d*\\s*)*";
		Pattern pa2 = Pattern.compile(pattern2);
		boolean matches2 = true;
		String pattern3= "\\w{2,}.*";
		Pattern pa3 = Pattern.compile(pattern3);
		boolean matches3 = true;
		while(sca.hasNextLine()){
			String line = sca.nextLine();
			Matcher m = pa.matcher(line);
			Matcher m2 = pa2.matcher(line);
			Matcher m3 = pa3.matcher(line);
			matches = m.matches();
			matches2 = m2.matches();
			matches3 = m3.matches();
			if(matches==false&&matches2==false&&matches3==false) {
				throw new WrongFileFormatException("this is not a ply file");
			}
			str.add(line);
		}
		if(str.size()<9) {
			throw new WrongFileFormatException("this is not a ply file");
		}
		int start = 0;
		for(int i = 0;i<str.size();i++) {
			String g = str.get(i);
			String[] subg = g.split("\\s+");
			if(subg[0].equals(new String("end_header"))) {
				start = i;
			}
		}
		if(start==0) {
			return null;
		}
		String[] sub1 = str.get(2).split("\\s+");
		String fc = sub1[sub1.length-1];
		int f = Integer.valueOf(fc);
		String[] sub2 = str.get(6).split("\\s+");
		String efc = sub2[sub2.length-1];
		int ef = Integer.valueOf(efc);
		int startface = start+f+1;
		for(int i=startface;i<ef+startface;i++) {
			String faces = str.get(i);
			String[] listfaces = faces.split("\\s+");
			int iter = Integer.parseInt(listfaces[0]);
			LinkedHashSet<Vertex> v = new LinkedHashSet<Vertex>();
			for(int z = 1;z<iter+1;z++) {
				int find=Integer.parseInt(listfaces[z]);
				String need = str.get(find+start+1);
				String[] vertex = need.split("\\s+");
				Vertex added = new Vertex(Double.parseDouble(vertex[0]),Double.parseDouble(vertex[1]),Double.parseDouble(vertex[2]));
				v.add(added);
			}
			Polygon p = new Polygon(v);
			result.add(p);
		}
		return result;
	}

}
