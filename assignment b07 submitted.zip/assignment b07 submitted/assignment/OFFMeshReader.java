package assignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OFFMeshReader implements MeshReader {

	@Override
	public HashSet<Polygon> read(String fileName) throws FileNotFoundException, WrongFileFormatException {
		Scanner sca= new Scanner(new File(fileName));
		ArrayList<String> str=new ArrayList<String>();
		HashSet<Polygon> result = new HashSet<Polygon>();
		String pattern="OFF\\s*";
		Pattern pa = Pattern.compile(pattern);
		boolean matches = true;
		//String pattern2="(\\s*\\-?\\d+\\.*\\d*\\s*){3}\\s*";
		String pattern2="(\\s*\\-?\\d+\\.*\\d*\\s*){3}\\s*";
		Pattern pa2 = Pattern.compile(pattern2);
		boolean matches2 = true;
		//String pattern3= "(\\s*\\d+\\s*){6}\\s*";
		String pattern3= "(\\s*\\d+\\s*)*\\s*";
		Pattern pa3 = Pattern.compile(pattern3);
		boolean matches3 = true;
		while(sca.hasNextLine()){
			String line = sca.nextLine();
			Matcher m = pa.matcher(line);
			Matcher m2 = pa2.matcher(line);
			Matcher m3 = pa3.matcher(line);
			matches = m.matches();
			matches2 = m2.matches();
			matches3 = m3.matches();
			if(matches==false&&matches2==false&&matches3==false) {
				throw new WrongFileFormatException("this is not an off file");
			}
			str.add(line);
		}
		String[] command = str.get(1).split("\\s+");
		int numv = Integer.valueOf(command[0]);
		int numf = Integer.valueOf(command[1]);
		for(int i = 2+numv;i<2+numv+numf;i++) {
			LinkedHashSet<Vertex> p = new LinkedHashSet<Vertex>();
			String[] linep = str.get(i).split("\\s+");
			int numvertexp = Integer.valueOf(linep[0]);
			for(int z=0;z<numvertexp;z++) {
				int vnumber = Integer.valueOf(linep[z+1]);
				String vertexline=str.get(2+vnumber);
				String[] breakvertex = vertexline.split("\\s+");
				Vertex v = new Vertex(Double.parseDouble(breakvertex[0]),Double.parseDouble(breakvertex[1]),Double.parseDouble(breakvertex[2]));
				p.add(v);
			}
			Polygon poly = new Polygon(p);
			result.add(poly);
		}
		return result;
	}

}
