package assignment;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;

public class Mesh extends GraphicalObject{
	HashSet<Polygon> polygons;
	MeshReader reader;
	MeshWriter writer;
	public void setReader(MeshReader mr) {
		reader = mr;
	}
	public void setWriter(MeshWriter mw) {
		writer = mw;
	}
	public void readFromFile(String f) throws FileNotFoundException, WrongFileFormatException {
		polygons = reader.read(f);
	}
	public void writeToFile(String f) throws IOException {
		writer.write(f, polygons);
	}
	public void transform(double[][] rotate) {
		for(Polygon p: polygons) {
			p.transform(rotate);
		}
	}
	@Override
	public boolean equals(Object j) {
		if(j==null) {
			return false;
		}
		if(this.getClass()!=j.getClass()) {
			return false;
		}
		Mesh c = (Mesh) j;
		return this.polygons.equals(c.polygons);
	}
	@Override
	public int hashCode(){
		int result = 0;
		for(Polygon p:this.polygons) {
			result= result + p.hashCode();
		}
		return result;
	}


}
