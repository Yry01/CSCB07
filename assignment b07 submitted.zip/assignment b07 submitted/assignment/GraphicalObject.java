package assignment;

public abstract class GraphicalObject {
	public abstract void transform(double[][] rotate);
	public void rotateXAxis(double degree) {
		double[][] rotate= {{1,0,0},{0,Math.cos(degree),-Math.sin(degree)},{0,Math.sin(degree),Math.cos(degree)}};
		this.transform(rotate);
	}
	public void rotateYAxis(double degree) {
		double[][] rotate= {{Math.cos(degree),0,Math.sin(degree)},{0,1,0},{-Math.sin(degree),0,Math.cos(degree)}};
		this.transform(rotate);
	}
	public void rotateZAxis(double degree) {
		double[][] rotate= {{Math.cos(degree),-Math.sin(degree),0},{Math.sin(degree),Math.cos(degree),0},{0,0,1}};
		this.transform(rotate);
	}
}
