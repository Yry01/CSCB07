package assignment;

public class Vertex extends GraphicalObject {
	double x,y,z;
	public Vertex(double a, double b, double c) {
		this.x=a;
		this.y=b;
		this.z=c;
	}
	public void transform(double[][] rotate) {
		double insx = this.x;
		double insy = this.y;
		double insz = this.z;
		this.x=rotate[0][0]*insx+rotate[0][1]*insy+rotate[0][2]*insz;
		this.y=rotate[1][0]*insx+rotate[1][1]*insy+rotate[1][2]*insz;
		this.z=rotate[2][0]*insx+rotate[2][1]*insy+rotate[2][2]*insz;
	}
	@Override
	public int hashCode() {
		return (int) (x*1000+y*100+z*10);
	}
	@Override
	public boolean equals(Object obj) {
		if(obj==null) {
			return false;
		}
		if(this.getClass()!=obj.getClass()) {
			return false;
		}
		Vertex comp=(Vertex)obj;
		if(comp.x==this.x&&comp.y==this.y&&comp.z==this.z) {
			return true;
		}
		else {
			return false;
		}
	}
	@Override
	public String toString() {
		String a = String.valueOf(this.x);
		String b = String.valueOf(this.y);
		String c = String.valueOf(this.z);
		return a+" "+b+" "+c;
		
	}
}
