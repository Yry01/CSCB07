package assignment;



import java.io.File;
import java.io.IOException;

public class Driver {
	public static void main(String[] args) throws WrongFileFormatException, IOException {
		Mesh mesh=new Mesh();
		mesh.setReader(new PLYMeshReader());
		mesh.readFromFile("C:\\Users\\15810\\testcase\\assignment b 07\\carply.ply");
		mesh.rotateZAxis(Math.PI*0.75);
		mesh.rotateXAxis(Math.PI*0.75);
		mesh.rotateYAxis(Math.PI*0.1);
		mesh.setWriter(new PLYMeshWriter());
		File f = new File("C:\\Users\\15810\\testcase\\assignment b 07\\getply.ply");
		f.createNewFile();
		mesh.writeToFile("C:\\Users\\15810\\testcase\\assignment b 07\\getply.ply");
		System.out.println("finishedget1");
		
		
		Mesh mesh2=new Mesh();
		mesh2.setReader(new OBJMeshReader());
		mesh2.readFromFile("C:\\Users\\15810\\testcase\\assignment b 07\\carobj.obj");
		mesh2.rotateZAxis(Math.PI);
		mesh2.rotateXAxis(Math.PI*0.5);
		mesh2.rotateYAxis(Math.PI*0.1);
		mesh2.setWriter(new OBJMeshWriter());
		File f2 = new File("C:\\Users\\15810\\testcase\\assignment b 07\\getobj.obj");
		f2.createNewFile();
		mesh2.writeToFile("C:\\Users\\15810\\testcase\\assignment b 07\\getobj.obj");
		System.out.println("finishedget2");
		
		
		Mesh mesh3=new Mesh();
		mesh3.setReader(new OFFMeshReader());
		mesh3.readFromFile("C:\\Users\\15810\\testcase\\assignment b 07\\caroff.off");
		mesh3.rotateZAxis(Math.PI);
		mesh3.rotateXAxis(Math.PI*0.5);
		mesh3.rotateYAxis(Math.PI*0.1);
		mesh3.setWriter(new OFFMeshWriter());
		File f3 = new File("C:\\Users\\15810\\testcase\\assignment b 07\\getoff.off");
		f3.createNewFile();
		mesh3.writeToFile("C:\\Users\\15810\\testcase\\assignment b 07\\getoff.off");
		System.out.println("finishedget3");
		
		Mesh mesh4=new Mesh();
		mesh4.setReader(new OFFMeshReader());
		mesh4.readFromFile("C:\\Users\\15810\\testcase\\mytest\\myoff.txt");
		mesh4.rotateZAxis(Math.PI);
		mesh4.rotateXAxis(Math.PI*0.5);
		mesh4.rotateYAxis(Math.PI*0.1);
		mesh4.setWriter(new OFFMeshWriter());
		File f4 = new File("C:\\Users\\15810\\testcase\\mytest\\getoff.txt");
		f4.createNewFile();
		mesh4.writeToFile("C:\\Users\\15810\\testcase\\mytest\\getoff.txt");
		System.out.println("finishedget4");
	}

}
