package assignment;

import java.util.LinkedHashSet;

public class Polygon extends GraphicalObject {
	LinkedHashSet<Vertex> vertices;
	public Polygon(LinkedHashSet<Vertex> a) {
		vertices=a;
	}
	public void transform(double[][] b) {
		for(Vertex element:this.vertices) {
			element.transform(b);
		}
	}
	@Override
	public int hashCode() {
		int sum = 0;
		for(Vertex v:vertices) {
			sum+=v.hashCode();
		}
		return sum;
	}
	@Override
	public boolean equals(Object j) {
		if(j==null) {
			return false;
		}
		if(this.getClass()!=j.getClass()) {
			return false;
		}
		Polygon t = (Polygon)j;
		return t.vertices.equals(vertices);
	}
}
