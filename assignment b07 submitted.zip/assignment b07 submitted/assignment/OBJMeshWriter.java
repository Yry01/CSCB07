package assignment;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

public class OBJMeshWriter implements MeshWriter{
	public void write(String fileName, HashSet<Polygon> polygons) throws IOException {
		FileWriter f = new FileWriter(fileName,false);
		ArrayList<Vertex> ver= new ArrayList<Vertex>();
		for(Polygon p: polygons) {
			for(Vertex v:p.vertices) {
				if (ver.contains(v)==false) {
					ver.add(v);
				}
			}
		}
		for(Vertex v:ver) {
			String a = "v"+" "+String.valueOf(v.x)+" "+String.valueOf(v.y)+" "+String.valueOf(v.z);
			f.write(a+"\n");
		}
		for(Polygon p:polygons) {
			f.write("f ");
			for(Vertex x:p.vertices) {
				for(int i = 0;i<ver.size();i++) {
					if(x.equals(ver.get(i))) {
					f.write(String.valueOf(i+1)+" ");
					break;
					}
			    }
			}
			f.write("\n");
		}
		f.close();
	}

}
