package assignment;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

public class OFFMeshWriter implements MeshWriter{

	@Override
	public void write(String fileName, HashSet<Polygon> polygons) throws IOException {
		FileWriter f = new FileWriter(fileName,false);
		ArrayList<Vertex> ver= new ArrayList<Vertex>();
		for(Polygon p: polygons) {
			for(Vertex v:p.vertices) {
				if (ver.contains(v)==false) {
					ver.add(v);
				}
			}
		}
		f.write("OFF\n");
		f.write(Integer.toString(ver.size())+" "+Integer.toString(polygons.size())+" 0\n");
		for(Vertex v:ver) {
			String line = String.valueOf(v.x)+" "+String.valueOf(v.y)+" "+String.valueOf(v.z);
			f.write(line+"\n");
		}
		for(Polygon p:polygons) {
			f.write(String.valueOf(p.vertices.size()));
			for(Vertex x:p.vertices) {
				for(int i=0;i<ver.size();i++) {
					if(x.equals(ver.get(i))){
						f.write(" ");
						f.write(String.valueOf(i));
						break;
					}
				}
			}
			f.write(" 220 220 220");
			f.write("\n");
		}
		f.close();
	}

}
